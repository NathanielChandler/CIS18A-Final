/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package starshipmain;



/**
 *
 * @author ncc
 */
public class RandomWeaponsGenerator
{
    private int choice; 
        
    
    

    public Weapon rnd()
    {
        choice = (int)Math.ceil(Math.random() * 11);
        String iName = "";
        int munitionsAmount = 0;
        int damage = 0;
        
        Weapon n = new Weapon();
        
        switch(choice)
    {
        case 1: 
            iName = "Rocket Launcher";
            munitionsAmount = 10;
            damage = 30;
            break;
        case 2:
            iName = "Missiles";
            munitionsAmount = 8;
            damage = 50;
            break;
        case 3:
            iName = "Super Missiles";
            munitionsAmount = 3;
            damage = 65;
            break;
        case 4:
            iName = "Heavy Machine Gun";
            munitionsAmount = 100000;
            damage = 3;
            break;    
        case 5:
            iName = "Bombs";
            munitionsAmount = 100;
            damage = 45;
            break;
        case 6:
            iName = "Lasers";
            munitionsAmount = 300000000;
            damage = 5;
            break;
        case 7:
            iName = "Nuke Bomb";
            munitionsAmount = 1;
            damage = 150;
            break;
        case 8:
            iName = "BB Gun";
            munitionsAmount = 300000000;
            damage = 1;
            break;
        case 9:
            iName = "Mines";
            munitionsAmount = 3;
            damage = 90;
            break; 
        case 10:
            iName = "Fire Missiles";
            munitionsAmount = 4;
            damage = 95;
            break;   
        case 11:
            iName = "Ice Missiles";
            munitionsAmount = 4;
            damage = 94;
            break;    
        default:
            System.out.println("You screwed up.");
    }
        
        n.setWeaponsName(iName);
        n.setMunitionsAmount(munitionsAmount);
        n.setDamage(damage);
        
        
        return n;
    }
}
