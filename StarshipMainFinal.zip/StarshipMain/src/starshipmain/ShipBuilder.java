package starshipmain;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


/**
 *
 * @author Owner
 */
public class ShipBuilder {
    
    private String send;    
    
    
    public String setShip(Ship ship){//classifications of each
        
        send = new String();
        send += ship.getName() + "\n";
        send += "  Ship Health: " + (int)(ship.getCurrentHealth()) + " / " + (int)(ship.getMaxHealth()) + " | Energy Reserves: " + ship.getEnergy() + "\n\n";
        for(int i = 0; i<ship.getRooms().size(); i++){
            
            send += "[";
            if(ship.getCrew().size() >= 2)
            {
                if(ship.getRoom(i).getOccupant() == ship.getCrew(0))
                {
                    send += "C";
                }
                else if(ship.getRoom(i).getOccupant() == ship.getCrew(1))
                {
                    send += "G";
                }
                else if(ship.getRoom(i).getOccupant() == ship.getCrew(2))
                {
                    send += "E";
                }
                else
                {
                    send += "_";
                }
            }
            else
            {
                send += "*";
            }
            
            send += "]  < " + (i+1) + ". ";
            
            if(ship.getRoom(i).getCurrentHealth() > 0)
            {
                if(ship.getRoom(i).getClassification() == 2)
                {
                    send += ship.getRoom(i).getWeapon().getWeaponsName() + " | Ammo: " + ship.getRoom(i).getWeapon().getMunitionsAmount();
                }
                else
                {
                    send += ship.getRoom(i).getName();
                }

                send += " | Health: " + (int)(ship.getRoom(i).getCurrentHealth()) + " / " + (int)(ship.getRoom(i).getMaxHealth()) + " | Energy Pods: " + ship.getRoom(i).getEnergy();
            }
            else
            {
                send += " -SYSTEMS OFFLINE- ";
            }
            
            if(i<(ship.getRooms().size()-1))
            {
                send += "\n| |\n";
            }
            else
            {
                send += "\n^^^\n\n";
            }
            
        }
        return send;
    }

 
    
}