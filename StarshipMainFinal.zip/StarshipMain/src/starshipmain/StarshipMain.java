package starshipmain;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

//import java.util.*;
//import java.util.Random;

/**
 *
 * @author Owner
 */
public class StarshipMain
{   private static MainInterface playerInterface;

    /**
     * @param args the command line arguments
     */
    public static MainInterface getInterface(){
        return playerInterface;
    }
    
    public static void main(String[] args) 
    {
        // TODO code application logic here
       
        playerInterface = new MainInterface();
        playerInterface.Prelude();
        /*while (playerInterface.getEndGame() == false)
        {
            playerInterface.Enemy();
            
            playerInterface.CharacterMovement();
        }*/
        
         //String shipName;
        //String crewName;
       // String playerInput;
        
       // boolean done = false;
        
        //Scanner reader = new Scanner(System.in);
        
        //runs through each of the methods in the Ship abstract
        //System.out.println("Please name your ship:");
        //shipName = reader.nextLine();
        
        // Creating a ship with 3-5 health per room as well as setting global energy and AP
        //Ship ship01 = new Ship(shipName);
        /*ship01.randomize(3, 5);
        ship01.setGlobalEnergy(500);
        ship01.setActionPoints(5);*/
        
        // Allows user to make a name for the commander
        /*System.out.println("Enter commander name:");
        crewName = reader.nextLine();
        
        // This creates a crew member and adds them to the Array List
        Crew commander = new Crew(1);
        commander.setName(crewName);
        ship01.addCrew(commander);
        
        // Allows user to make a name for the gunner
        System.out.println("Enter gunner name:");
        crewName = reader.nextLine();
        
        // This creates a crew member and adds them to the Array List
        Crew gunner = new Crew(2);
        gunner.setName(crewName);
        ship01.addCrew(gunner);
        
        // Allows user to make a name for the engineer
        System.out.println("Enter engineer name:");
        crewName = reader.nextLine();
        
        // This creates a crew member and adds them to the Array List
        Crew engineer = new Crew(3);
        engineer.setName(crewName);
        ship01.addCrew(engineer);
                
        System.out.println("HP : " + ship01.getCurrentHealth() + " / " + ship01.getMaxHealth());
        System.out.println("Current ship energy: " + ship01.getGlobalEnergy());
        System.out.println("Current unspent AP: "  + ship01.getActionPoints());
        System.out.println("Is Destroyed : " + ship01.isDestroyed());
        
        //cycles through all of the crew and prints out their name
        for (int i = 0;i < ship01.getCrew().size();i++)
        {
            String g = ship01.getCrew(i).getName();
            //System.out.println(g + " is a " + ship01.getCrew(i).getJobTitle());
            if (i == 0)
            {
                System.out.println(g + " is a Commander");
                System.out.println(commander.getCurrentHealth() + " / " + commander.getMaxHealth());
            }
            else if (i == 1)
            {
                System.out.println(g + " is a Gunner");
                System.out.println(gunner.getCurrentHealth() + " / " + gunner.getMaxHealth());
            }
            else if (i == 2)
            {
                System.out.println(g + " is an Engineer");
                System.out.println(engineer.getCurrentHealth() + " / " + engineer.getMaxHealth() + "\n");
            }
        }*/
        
        // THIS CREATES ROOMS!!!!
       /* Room blasters = new Room(2);
        blasters.randomize(3, 5);
        
        // This adds rooms to the array list
        ship01.addRoom(blasters);

       /* System.out.println("Name");
        String n= reader.nextLine();
        System.out.println("Type");
        String t = reader.nextLine();
        System.out.println("Munitioin amount");
        int ma = reader.nextInt();
        System.out.println("Range");
        int range = reader.nextInt();
        System.out.println("Damage");
        int damage = reader.nextInt();
        blasters.createGun(n, t, ma,range,damage);
        */
                
        //< default rooms are 0 - 2
        //cycles through all of the rooms and prints out their name
        /*for (int i = 0;i < ship01.getRooms().size();i++){
            String g = ship01.getRoom(i).getName();
            ship01.getRoom(i).setRoomEnergy(100);
            System.out.println(g + " Room");
            System.out.println("Current room energy: " + ship01.getRoom(i).getRoomEnergy());
            if(ship01.getRoom(i).getClassification() == 2){
                System.out.println("This room contains - " + ship01.getRoom(i).getWeapon().getWeaponsName() );
            }
            System.out.println("");
        }

        ship01.setMaxHealth(0);
        ship01.setCurrentHealth(0);
        
        System.out.println("Ship HP : "+ship01.getCurrentHealth() + " / " + ship01.getMaxHealth());
        System.out.println("Is Destroyed : " + ship01.isDestroyed());*/
        /*System.out.println("The ship is being attacked . . . By itself!");
        ship01.getRoom(0).attack(ship01.getRoom(1), ship01.getRoom(0), (float) .01);
        System.out.println(ship01.getRoom(0).getCurrentHealth()+" / "+ ship01.getRoom(0).getMaxHealth());
        */
        //This is an example of Room v room combat that we'll use in the game 
        
        /*System.out.println("Rename ship:");
        shipName = reader.nextLine();
        ship01.setName(shipName);
        System.out.println("The ship name is now -"+ship01.getName());*/
        
        // This is currently the way characters are moving through the rooms
        // Need to add questions for who is going to the room and what they want to do in the room
        /*while(done == false)
        {
            CharacterController controller = new CharacterController();
            
            if (ship01.getActionPoints() > 0)
            {
                System.out.println("\nWhat room do you want to move to? (C, W, E, or CommandRoom, WeaponsRoom, EngineRoom)");
                playerInput = reader.next();
                String choice = playerInput;

                controller.MoveToCommandRoom(choice);
                controller.MoveToWeaponsRoom(choice);
                controller.MoveToEngineRoom(choice);

                if (controller.checkIfValidRoom())
                {
                    int energyDepleter = new Random().nextInt(5 + 1) + 5;
                    ship01.setGlobalEnergy(ship01.getGlobalEnergy() - energyDepleter);
                    ship01.setActionPoints(ship01.getActionPoints() - 1);
                    System.out.println("Current unspent AP: " + ship01.getActionPoints());
                    System.out.println("Current ship energy: " + ship01.getGlobalEnergy());
                }
            }
            else
            {
                break;
            }
            
            //ship and room hp systems need to be implemented
            //crew memebrs need to be implemented
            //timer system needs to be implemented
        }*/
        
    }
    
    
    
}
