// CREATED BY: KYLE BUE

package starshipmain;

// Class that holds data for different jobs the crew will obtain

public class Jobs extends Stats
{
    
    
    public Jobs (int c)
    {
        super.setClassification(c);
        
        switch (c)
        {
            case 1:
                super.setName("Commander");
                
                break;
            case 2:
                super.setName("Gunner");
                break;
            case 3:
                super.setName("Engineer");
                break;
            default:
                super.setName("THIS SHOULDN'T EXIST!");
                break;
        }
    }
    
    public void doJob(Crew crew, Room room, int doing, Ship ship){
        
        MainInterface playerInterface =  StarshipMain.getInterface();
        
        //System.out.println("im here");
        
            switch(doing){
                case(1): 
                    //System.out.print(room.getEnergy());
                    if(room.getCurrentHealth()>0)
                    {
                        
                            crew.setEnergy(crew.getEnergy() + room.getEnergy());
                            room.setEnergy(0);
                            System.out.println("\n" + crew.getName() + " is now holding " + crew.getEnergy() + " Energy Pods.");
                        
                        if(room.getClassification() == 1){
                            System.out.println(crew.getName() + " has deposited " + crew.getEnergy() + " Energy Pods into the ship's mainframe.");
                            ship.setEnergy(ship.getEnergy() + crew.getEnergy());
                            crew.setEnergy(0);
                            
                        }
                        System.out.println("\n");
                    }
                    else
                    {
                        System.out.println("\nThe room's systems are offline!\n");
                    }
                    //System.out.print(room.getEnergy());
                        break;
                    
                case(2): //System.out.println("im here");
                         //System.out.println(room.getCurrentHealth());
                    if(room.getCurrentHealth()> 0){
                        if(room.getClassification() == 2)
                        {   

                           if(room.getWeapon().getMunitionsAmount() >=1)
                            {
                                playerInterface.combat(room);
                            }else
                            {
                                System.out.println("\n"+room.getWeapon().getWeaponsName()+" is out of ammo!\n");
                            }
                        }
                        else
                        {
                            System.out.println("\n" +crew.getName() + " does not see a trigger in this room.\n");
                        }
                    }
                    else{
                        System.out.println("\nThe room's systems are offline!\n");
                    }
                        break;
                case(3):
                   // System.out.println(room.getCurrentHealth());
                    if(room.getCurrentHealth()> 0 && room.getCurrentHealth() < room.getMaxHealth())
                    {
                        float heals = (room.getMaxHealth() - room.getCurrentHealth())* (float) .5;
                        room.setCurrentHealth(room.getCurrentHealth() + heals);
                        System.out.println("\n"+crew.getName() + " fixed " + room.getName() + " for " + (int)heals + " points\n");
                    }
                    else if(room.getCurrentHealth() <= 0)
                    {
                        float heals = room.getMaxHealth() / 4;
                        room.setCurrentHealth(heals);
                        System.out.println("\n"+crew.getName() + " repaired " + room.getName()+"\n");
                    }
                    else
                    {
                        System.out.println("\n"+crew.getName() + " did not find any leaks in this room.\n   However, they did find a nice cup of coffee . . . from three weeks ago.\n");
                    }
                    ship.setCurrentHealth(0);
                    if(room.getClassification() == 2){
                        double chance = Math.random();
                        if(chance < .3){
                            room.getWeapon().setMunitionsAmount(room.getWeapon().getMunitionsAmount()+1);
                            System.out.println( "\n" + crew.getName() + " was able to produce an extra piece of ammunition!\n");
                        }
                    }
                    //System.out.println(room.getCurrentHealth());
                        break;
            }
        
    
        
    }
    
    
}
