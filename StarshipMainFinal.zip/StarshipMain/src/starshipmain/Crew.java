// CREATED BY: Kyle Bue

package starshipmain;

// Class that acts as a blueprint to make characters
public class Crew extends Stats
{
    private Jobs currentJob;
    private String memberName = "";
    
    public Crew (int i)
    {
        currentJob = new Jobs(i);
    }
    
    @Override
    public String getName()
    {
        return memberName;
    }
    @Override
    public void setName(String mMemberName)
    {
        memberName = mMemberName;
    }

    /**
     * @return the currentJob
     */
    public Jobs getCurrentJob() {
        return currentJob;
    }

    /**
     * @param currentJob the currentJob to set
     */
    public void setCurrentJob(Jobs currentJob) {
        this.currentJob = currentJob;
    }
}
