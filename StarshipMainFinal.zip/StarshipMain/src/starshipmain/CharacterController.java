/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package starshipmain;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Scanner;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import starshipmain.Crew;
import starshipmain.Room;
import starshipmain.Ship;
/**
 *
 * @author ncc
 */
public class CharacterController 
{
    private BufferedReader input = null;
    private Scanner pInput = null;
    private String roomName;
    private String playersChoice;
    private int roomChoice;
    private boolean isValidChoice = false;    
    
    
    
    public int SelectCommander(String choice, Crew commander, Ship ship)
    {   
        if (choice.contains("c") || choice.contains("Commander"))
        {
            System.out.println("Would you like to move or perform an action? (move/action)");
            
                try {
                    input = new BufferedReader(new InputStreamReader(System.in));
                    playersChoice = input.readLine();
                    playersChoice = playersChoice.toLowerCase();
                    if(playersChoice.contains("action"))
                    {
                        Room room = null;
                        for(int i = 0; i < ship.getRooms().size();i++)
                        {
                            if(ship.getRoom(i).getOccupant()==commander)
                            {
                                room = ship.getRoom(i);
                                commander.getCurrentJob().doJob(commander, room,1, ship);
                                isValidChoice = true;
                                return 0;
                            }   
                        } 
                    }
                    else if(playersChoice.contains("move"))
                    {
                        System.out.println("\nYou have chosen to move " + commander.getName() + ".");
                        System.out.println("Which room would you like to move " + commander.getName() + "?");

                        System.out.println("\nAvailable rooms:");
                        for (int i = 0; i < ship.getRooms().size(); i++)
                        {
                            if (ship.getRoom(i).getClassification() == 2)
                            {
                                System.out.print((i + 1)+" Weapons room - " + ship.getRoom(i).getWeapon().getWeaponsName());
                            }
                            else
                            {
                                System.out.print((i + 1) + " " + ship.getRoom(i).getName() + " room");
                            }

                            if (ship.getRoom(i).isIsOccupied())
                            {
                                if (ship.getRoom(i).getOccupant() != null)
                                {
                                    System.out.println(" - This room is occupied by " + ship.getRoom(i).getOccupant().getName());
                                }
                            }
                            else
                            {
                                System.out.println("");
                            }
                        }
                        
                    }
                    else
                    {
                        System.out.println("Invalid choice. Try again (move/action)");
                        SelectCommander(choice, commander, ship);
                    }
                }   catch (IOException ex) {
                    Logger.getLogger(CharacterController.class.getName()).log(Level.SEVERE, null, ex);
                    playersChoice = "i";
                }
                try {
                    roomChoice = Integer.parseInt(input.readLine());
                    while(true)
                    {
                        if (roomChoice > ship.getRooms().size())
                        {
                            System.out.println("Invalid choice. Try again\n");
                            break;
                        }
                        else if (roomChoice == 1 && !ship.getRoom(0).isIsOccupied())
                        {
                            ResetRoom(commander, ship);
                            ship.getRoom(0).setIsOccupied(true);
                            ship.getRoom(0).setOccupant(commander);
                            isValidChoice = true;
                            MoveToCommandRoom(roomChoice, commander);
                            break;
                        }
                        else if (ship.getRoom(roomChoice - 1).getClassification() == 2 && !ship.getRoom(roomChoice - 1).isIsOccupied())
                        {
                            ResetRoom(commander, ship);
                            ship.getRoom(roomChoice - 1).setIsOccupied(true);
                            ship.getRoom(roomChoice - 1).setOccupant(commander);
                            isValidChoice = true;
                            MoveToWeaponsRoom(roomChoice, commander, ship);
                            break;
                        }
                        else if (ship.getRoom(roomChoice - 1).getClassification() == 3 && !ship.getRoom(roomChoice - 1).isIsOccupied())
                        {
                            ResetRoom(commander, ship);
                            ship.getRoom(roomChoice - 1).setIsOccupied(true);
                            ship.getRoom(roomChoice - 1).setOccupant(commander);
                            isValidChoice = true;
                            MoveToEngineRoom(roomChoice, commander);
                            break;
                        }
                        else if (ship.getRoom(roomChoice - 1).isIsOccupied())
                        {
                            System.out.println("ERROR: Room is currently occupied!");
                            isValidChoice = false;
                        }

                    }
                } catch (IOException ex) {
                    Logger.getLogger(CharacterController.class.getName()).log(Level.SEVERE, null, ex);
                    roomChoice = -1;
                }
            }
            return 0;
        }
    
    public int SelectGunner(String choice, Crew gunner, Ship ship)
    {
        if (choice.contains("g") || choice.contains("Gunner"))
        {
            
            System.out.println("Would you like to move or perform an action? (move/action)");
            try {
            input = new BufferedReader(new InputStreamReader(System.in));
            playersChoice = input.readLine();
            playersChoice = playersChoice.toLowerCase();
            
       
            if(playersChoice.equalsIgnoreCase("action"))
            {   
                Room room = null;
                for(int i = 0; i < ship.getRooms().size();i++){
                    if(ship.getRoom(i).getOccupant()==gunner){
                        room = ship.getRoom(i);
                        gunner.getCurrentJob().doJob(gunner, room, 2, ship);
                        isValidChoice = true;
                        return 0;
                    }
                }                
            }
            else if(playersChoice.contains("move"))
            {
                System.out.println("\nYou have chosen to move " + gunner.getName() + ".");
                System.out.println("Which room would you like to move " + gunner.getName() + "?");

                System.out.println("\nAvailable rooms:");
                for (int i = 0; i < ship.getRooms().size(); i++)
                {
                    if (ship.getRoom(i).getClassification() == 2)
                    {
                        System.out.print((i + 1)+" Weapons room - " + ship.getRoom(i).getWeapon().getWeaponsName());
                    }
                    else
                    {
                        System.out.print((i + 1) + " " + ship.getRoom(i).getName() + " room");
                    }

                    if (ship.getRoom(i).isIsOccupied())
                    {
                        if (ship.getRoom(i).getOccupant() != null)
                        {
                            System.out.println(" - This room is occupied by " + ship.getRoom(i).getOccupant().getName());
                        }
                    }
                    else
                    {
                        System.out.println("");
                    }
                    
                }
            }
            else
            {
                System.out.println("Invalid choice. Try again (move/action)");
                SelectCommander(choice, gunner, ship);
            }
            }   catch (IOException ex) {
                Logger.getLogger(CharacterController.class.getName()).log(Level.SEVERE, null, ex);
                playersChoice = "i";
            }
                
            try {
                roomChoice = Integer.parseInt(input.readLine());
                if (roomChoice == 1 && !ship.getRoom(0).isIsOccupied())
                {
                    ResetRoom(gunner, ship);
                    ship.getRoom(0).setIsOccupied(true);
                    ship.getRoom(0).setOccupant(gunner);
                    isValidChoice = true;
                    MoveToCommandRoom(roomChoice, gunner);
                }
                else if (ship.getRoom(roomChoice - 1).getClassification() == 2 && !ship.getRoom(roomChoice - 1).isIsOccupied())
                {
                    ResetRoom(gunner, ship);
                    ship.getRoom(roomChoice - 1).setIsOccupied(true);
                    ship.getRoom(roomChoice - 1).setOccupant(gunner);
                    isValidChoice = true;
                    MoveToWeaponsRoom(roomChoice, gunner, ship);
                }
                else if (ship.getRoom(roomChoice - 1).getClassification() == 3 && !ship.getRoom(roomChoice - 1).isIsOccupied())
                {
                    ResetRoom(gunner, ship);
                    ship.getRoom(roomChoice - 1).setIsOccupied(true);
                    ship.getRoom(roomChoice - 1).setOccupant(gunner);
                    isValidChoice = true;
                    MoveToEngineRoom(roomChoice, gunner);
                }
                else if (ship.getRoom(roomChoice - 1).isIsOccupied())
                {
                    System.out.println("ERROR: Room is currently occupied!");
                    isValidChoice = false;
                }
            } catch (IOException ex) {
                Logger.getLogger(CharacterController.class.getName()).log(Level.SEVERE, null, ex);
                roomChoice = -1;
            }    
        }   
        return 0;
    }
    public int SelectEngineer(String choice, Crew engineer, Ship ship)
    {
        if (choice.equalsIgnoreCase("e") || choice.equalsIgnoreCase("Engineer"))
        {   
            System.out.println("Would you like to move or perform an action? (move/action)");
            try {
            input = new BufferedReader(new InputStreamReader(System.in));
            playersChoice = input.readLine();
            playersChoice = playersChoice.toLowerCase();
            
            if(playersChoice.contains("action"))
            {   
                Room room = null;
                for(int i = 0; i < ship.getRooms().size();i++){
                    if(ship.getRoom(i).getOccupant()==engineer){
                        room = ship.getRoom(i);
                        engineer.getCurrentJob().doJob(engineer, room, 3, ship);
                        isValidChoice = true;
                        return 0;
                    }
                }
            }
            else if(playersChoice.contains("move"))
            {
                System.out.println("\nYou have chosen to move " + engineer.getName() + ".");
                System.out.println("Which room would you like to move " + engineer.getName() + "?");

                System.out.println("\nAvailable rooms:");
                for (int i = 0; i < ship.getRooms().size(); i++)
                {
                    if (ship.getRoom(i).getClassification() == 2)
                    {
                        System.out.print((i + 1)+" Weapons room - " + ship.getRoom(i).getWeapon().getWeaponsName());
                    }
                    else
                    {
                        System.out.print((i + 1) + " " + ship.getRoom(i).getName() + " room");
                    }

                    if (ship.getRoom(i).isIsOccupied())
                    {
                        if (ship.getRoom(i).getOccupant() != null)
                        {
                            System.out.println(" - This room is occupied by " + ship.getRoom(i).getOccupant().getName());
                        }
                    }
                    else
                    {
                        System.out.println("");
                    }
                }
            }
            else
            {
                System.out.println("Invalid choice. Try again (move/action)");
                SelectCommander(choice, engineer, ship);
            }
            }   catch (IOException ex) {
                Logger.getLogger(CharacterController.class.getName()).log(Level.SEVERE, null, ex);
                playersChoice = "i";
            }
            try {
                roomChoice = Integer.parseInt(input.readLine());
                if (roomChoice == 1 && !ship.getRoom(0).isIsOccupied())
                {
                    ResetRoom(engineer, ship);
                    ship.getRoom(0).setIsOccupied(true);
                    ship.getRoom(0).setOccupant(engineer);
                    isValidChoice = true;
                    MoveToCommandRoom(roomChoice, engineer);
                }
                else if (ship.getRoom(roomChoice - 1).getClassification() == 2 && !ship.getRoom(roomChoice - 1).isIsOccupied())
                {
                    ResetRoom(engineer, ship);
                    ship.getRoom(roomChoice - 1).setIsOccupied(true);
                    ship.getRoom(roomChoice - 1).setOccupant(engineer);
                    isValidChoice = true;
                    MoveToWeaponsRoom(roomChoice, engineer, ship);
                }
                else if (ship.getRoom(roomChoice - 1).getClassification() == 3 && !ship.getRoom(roomChoice - 1).isIsOccupied())
                {
                    ResetRoom(engineer, ship);
                    ship.getRoom(roomChoice - 1).setIsOccupied(true);
                    ship.getRoom(roomChoice - 1).setOccupant(engineer);
                    isValidChoice = true;
                    MoveToEngineRoom(roomChoice, engineer);
                }
                else if (ship.getRoom(roomChoice - 1).isIsOccupied())
                {
                    System.out.println("ERROR: Room is currently occupied!");
                    isValidChoice = false;
                }
            } catch (IOException ex) {
                Logger.getLogger(CharacterController.class.getName()).log(Level.SEVERE, null, ex);
                roomChoice = -1;
            } 
        }
        return 0;
    }

    public void MoveToCommandRoom(int choice, Crew crew)
    {
        System.out.println("You have moved " + crew.getName() + " to the Command Room");
    }
    public void MoveToWeaponsRoom(int choice, Crew crew, Ship ship)
    {
        System.out.println("You have moved " + crew.getName() + " to the Weapons Room - " + ship.getRoom(choice - 1).getWeapon().getWeaponsName());
    }
    public void MoveToEngineRoom(int choice, Crew crew)
    {
        System.out.println("You have moved " + crew.getName() + " to the Engine Room");
    }
    
    public boolean checkIfValidChoice()
    {
        return isValidChoice;
    }    
    
    public void ResetRoom(Crew crew, Ship ship)
    {
        
        for (int i = 0; i < ship.getRooms().size(); i++)
        {
            if (ship.getRoom(i).getOccupant() != null)
            {
                if (ship.getRoom(i).getOccupant().equals(crew))
                {
                    ship.getRoom(i).setIsOccupied(false);
                }
            }
        }
    }
}
