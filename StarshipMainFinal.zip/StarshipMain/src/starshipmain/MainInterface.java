/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package starshipmain;
import java.util.Random;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.logging.Level;
import java.util.logging.Logger;
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author ncc
 */
public class MainInterface 
{
    private BufferedReader input = null;
    private String playersInput;
    private String shipName;
    private String crewName;
    private String choice;
    private boolean done = false;
    private boolean dontRun = false;
    
    Ship ship01;
    Ship enemy = new Ship("");
    StarshipMain main = new StarshipMain();
    
    public void Prelude()
    {
        System.out.println("Welcome to StarShip 00000 \n");
        System.out.println("    Created by: " + "\n" + "Kyle Bue, Lewis Griffith" + "\n" + "Nathaniel Chandler, and Joseph Alas \n");
        System.out.println("Loosely based on Space Alert \n");
        System.out.println("   Created by: " + "\n" + "Vlaada Chvatil");
        System.out.println("Would you like to Play? (y / n)");
        
        Intro();
    }
    public void Intro()
    {
        while (dontRun == false)
        {
            try {
                input = new BufferedReader(new InputStreamReader(System.in));
                playersInput = input.readLine();
                playersInput = playersInput.toLowerCase();
                
                if(playersInput.equalsIgnoreCase("y"))
                {
                    //dontRun = false;
                    System.out.println("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n");
                    System.out.println("You are an Explorer attempting to find a new home for your people.\n" 
                               + "Your world is falling apart and soon will no longer be able to support life.\n" 
                               + "Your Mission is to find a world to inhabit at any cost.\n" 
                               + "Your mission has many perils we hope for your safe return.\n");
                    System.out.println("How to play the game: \n\n"
                   + "You have three different types of characters you can move or perform an action with.\n"
                   + "They are: \n\n"
                   + "- Commander\n"
                   + "- Gunner\n"
                   + "- Engineer\n\n"
                   + "The Commander can pick up energy in various rooms and stores them in the main room (Command room).\n"
                   + "The Gunner can shoot weapons at the enemy in its designated weapons room(s).\n"
                   + "The Engineer can repair rooms that are offline and has the possibility to produce ammunition.\n");
                    NameShip();
                }
                else if (playersInput.equalsIgnoreCase("n"))
                {
                    dontRun = true;
                }
                else
                {
                    System.out.println("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n");
                    System.out.println("\nNot a valid choice. Try again.\n");
                    Intro();
                }
            } catch (IOException ex) {
                Logger.getLogger(MainInterface.class.getName()).log(Level.SEVERE, null, ex);
                playersInput = "i";
            }
        }
    }
    
    public void NameShip()
    {
        System.out.println("Please name your ship");
        try {
            input = new BufferedReader(new InputStreamReader(System.in));
            playersInput = input.readLine();
        } catch (IOException ex) {
            Logger.getLogger(MainInterface.class.getName()).log(Level.SEVERE, null, ex);
            playersInput = "i";
        }
        
        System.out.println("\nSo your ship's name is: " + playersInput);
        System.out.println("Are you sure you want to name your ship " + playersInput + "?(y/n)");
        
        BuildShip();
        Enemy();
        CharacterMovement();
    }
    public void BuildShip()
    {
        try {
            input = new BufferedReader(new InputStreamReader(System.in));
            choice = input.readLine();
        } catch (IOException ex) {
            Logger.getLogger(MainInterface.class.getName()).log(Level.SEVERE, null, ex);
            choice = "i";
        }
        
        if(choice.equalsIgnoreCase("y"))
        {
            shipName = playersInput;
            ship01 = new Ship(shipName);
            ship01.randomize(50, 75);
            ship01.setEnergy(200);
            ship01.setActionPoints(4);

            BuildRooms();
        }
        else if (choice.equalsIgnoreCase("n"))
        {
            System.out.println("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n");
            NameShip();
        }
        else
        {
            System.out.println("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n");
            System.out.println("Invalid choice. Please try again.");
            NameShip();
        }
    }
    
    public void BuildRooms()
    {
        Room blasters = new Room(2);
        blasters.randomize(50, 75);
        
        // This adds rooms to the array list
        ship01.addRoom(blasters);
        
        // Used for testing purposes only
        /*for (int i = 0;i < ship01.getRooms().size();i++){
            String g = ship01.getRoom(i).getName();
            System.out.println(g + " Room");
            System.out.println("Current room energy: " + ship01.getRoom(i).getEnergy());
            if(ship01.getRoom(i).getClassification() == 2){
                System.out.println("This room contains - " + ship01.getRoom(i).getWeapon().getWeaponsName() );
            }
            System.out.println("");
        }*/

        ship01.setMaxHealth(0);
        ship01.setCurrentHealth(0);
        
        //System.out.println("\nShip HP : " + ship01.getCurrentHealth() + " / " + ship01.getMaxHealth());
        
        /*if(ship01.getCurrentHealth() <= 0)
        System.out.println("Is Destroyed : " + ship01.isDestroyed());*/
        
        BuildCrew();
    }
    
    public void BuildCrew()
    {
        System.out.println("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n");
        System.out.println("Enter commander name:");
        try {
            input = new BufferedReader(new InputStreamReader(System.in));
            crewName = input.readLine();
        } catch (IOException ex) {
            Logger.getLogger(MainInterface.class.getName()).log(Level.SEVERE, null, ex);
            crewName = "i";
        }
        
        // This creates a crew member and adds them to the Array List
        Crew commander = new Crew(1);
        commander.setName(crewName);
        ship01.addCrew(commander);
        
        // Allows user to make a name for the gunner
        System.out.println("Enter gunner name:");
        try {
            input = new BufferedReader(new InputStreamReader(System.in));
            crewName = input.readLine();
        } catch (IOException ex) {
            Logger.getLogger(MainInterface.class.getName()).log(Level.SEVERE, null, ex);
            crewName = "i";
        }
        
        // This creates a crew member and adds them to the Array List
        Crew gunner = new Crew(2);
        gunner.setName(crewName);
        ship01.addCrew(gunner);
        
        // Allows user to make a name for the engineer
        System.out.println("Enter engineer name:");
        try {
            input = new BufferedReader(new InputStreamReader(System.in));
            crewName = input.readLine();
        } catch (IOException ex) {
            Logger.getLogger(MainInterface.class.getName()).log(Level.SEVERE, null, ex);
            crewName = "i";
        }
        
        // This creates a crew member and adds them to the Array List
        Crew engineer = new Crew(3);
        engineer.setName(crewName);
        ship01.addCrew(engineer);
                
        //System.out.println("HP : " + ship01.getCurrentHealth() + " / " + ship01.getMaxHealth());
        //System.out.println("Current ship energy: " + ship01.getEnergy());
        
        //System.out.println("Is Destroyed : " + ship01.isDestroyed());
        
      
        
        
    }
    
    public void CharacterMovement()
    {   
        CharacterController controller = new CharacterController();
        Crew commander = ship01.getCrew(0);
        Crew gunner = ship01.getCrew(1);
        Crew engineer = ship01.getCrew(2);
        done = false;
        while(done == false && dontRun == false)
        {
            visual(ship01);
                       
            if (enemy.getCurrentHealth() <= 0)
            {
                System.out.println("\n\nCongratulations! You are a master of disaster!");
                System.out.println("Woud you like to play again? (y/n)");
                
                Intro();
            }
            else if (ship01.getActionPoints() > 0)
            {
                
                System.out.println("Current unspent AP: "  + ship01.getActionPoints());
                System.out.println("\nWhich crew member would you like to control? (C, G, E, or Commander, Gunner, Engineer)");
                try {
                    input = new BufferedReader(new InputStreamReader(System.in));
                    playersInput = input.readLine();
                } catch (IOException ex) {
                    Logger.getLogger(MainInterface.class.getName()).log(Level.SEVERE, null, ex);
                    playersInput = "i";
                }
                String choice = playersInput.toLowerCase();
                
                if (choice.contains("c") || choice.contains("Commander") || 
                        choice.contains("g") || choice.contains("Gunner") || 
                        choice.contains("e") || choice.contains("Engineer"))
                {
                    int x = controller.SelectCommander(choice,commander, ship01);
                    int y = controller.SelectGunner(choice, gunner, ship01);
                    int z = controller.SelectEngineer(choice, engineer, ship01);
                }
                else
                {
                    System.out.println("Error! Invalid Choice!");
                    done = false;
                }
                 
                if (controller.checkIfValidChoice())
                {
                    int energyDepleter = new Random().nextInt(5 + 1) + 5;
                    if(energyDepleter >= ship01.getEnergy())
                    {
                        ship01.setEnergy(0);
                        if(enemy != null && ship01.getEnergy() <= 0)
                        {
                            System.out.println("\n\nYou have failed to manage your ship well and you ran out of Energy! You are a failure at life!");
                            System.out.println("Would you like to play again? (y/n)");
                            Intro();
                        }
                    }
                    else
                    {
                    ship01.setEnergy(ship01.getEnergy() - energyDepleter);
                    ship01.setActionPoints(ship01.getActionPoints() - 1);
                    
                   // System.out.println("Current ship energy: " + ship01.getEnergy());
                   // System.out.println("Current ship health: " + ship01.getCurrentHealth());
                   
                    }
                }
            }
            else
            {   
                for (int i = 0; i < ship01.getRooms().size(); i++)
                {
                    int randomRoomEnergy = new Random().nextInt(4 + 1) + 4;
                    int newRoomEnergy = ship01.getRoom(i).getEnergy();
                    newRoomEnergy += randomRoomEnergy;
                    ship01.getRoom(i).setEnergy(newRoomEnergy);
                }
                enemyCombat(enemy, ship01);
                System.out.println("\n\n**************************E*N*E*M*Y*********************************\n");
                visual(enemy);
                System.out.println("********************************************************************\n\n");
                ship01.setActionPoints(4);
            }
            //ship and room hp systems need to be implemented
            //crew memebrs need to be implemented
            //timer system needs to be implemented
        }
         while((enemy != null && ship01.getCurrentHealth() <= 0) || (enemy != null && ship01.getActionPoints() <= 0))
            {
                if (ship01.getCurrentHealth() <= 0 || ship01.getEnergy() <= 0)
                {   
                    System.out.println("Your ship has been destroyed! You are a failure at life!");
                    System.out.println("Would you like to play again? (y/n)");
                    /*try {
                        input = new BufferedReader(new InputStreamReader(System.in));
                        playersInput = input.readLine();
                    } catch (IOException ex) {
                        Logger.getLogger(MainInterface.class.getName()).log(Level.SEVERE, null, ex);
                        playersInput = "i";
                    }*/
                    //if(playersInput.equalsIgnoreCase("Y"))
                    //{
                    //dontRun = true;
                    //done = true;
                        Intro();

                    //}
                    //else if (playersInput.equalsIgnoreCase("N"))
                    //{

                        //break;
                    //}
                    //else
                    //{
                        //System.out.println("That's not a choice, dummy! Try again... (y/n)");
                        //try {
                            //input = new BufferedReader(new InputStreamReader(System.in));
                            //playersInput = input.readLine();
                        //} catch (IOException ex) {
                            //Logger.getLogger(MainInterface.class.getName()).log(Level.SEVERE, null, ex);
                            //playersInput = "i";
                        //}

                }
            }
    }
    
    public void Enemy()
    {
            enemy = new Ship("");
            enemy.randomize(100, 150);
            enemy.setEnergy(500);
            enemy.setActionPoints(5);
            
            Notification(2);
            
            Room blasters = new Room(2);
            blasters.randomize(3, 5);
        for (int i = 0;i < enemy.getRooms().size();i++){
            String g = enemy.getRoom(i).getName();
            enemy.getRoom(i).setEnergy(0);
            /*
            System.out.println(g + " Room");
            System.out.println("Enemy room energy: " + enemy.getRoom(i).getEnergy());
            if(enemy.getRoom(i).getClassification() == 2){
                System.out.println("This room contains - " + enemy.getRoom(i).getWeapon().getWeaponsName() );
            }
            System.out.println("");
            */
                    
        }

        enemy.setMaxHealth(0);
        enemy.setCurrentHealth(0);
        
        //System.out.println("Ship HP : "+ enemy.getCurrentHealth() + " / " + enemy.getMaxHealth());
        
        //if(enemy.getCurrentHealth() <= 0)
        //System.out.println("Is Destroyed : " + enemy.isDestroyed());
        
    }
    public void combat(Room room){
        int chosen;
        float dodge = 0;
        Room defending;
           //System.out.println("im here");
        do{
            chosen = (int)(Math.random()* enemy.getRooms().size());
            defending = enemy.getRoom(chosen);
        }while(defending.getCurrentHealth() <= 0);
        //System.out.print(room.getCurrentHealth());
        //System.out.print(defending.getCurrentHealth());
        for(int i = 0; i< enemy.getRooms().size();i++){
            if(enemy.getRoom(i).getClassification() == 3){
                if(enemy.getRoom(i).getCurrentHealth() > 0){
                    dodge += .1;
                }
            }
        }
        //System.out.println(dodge);
        float damage = room.attack(room, defending, dodge);
        //System.out.println(damage);
        if (damage != -1)
        {
            System.out.println("\n"+room.getWeapon().getWeaponsName() +" has hit the enemy ship for " + damage + " damage!");
        }
        else
        {
            System.out.println("\n"+room.getWeapon().getWeaponsName() + " missed!!!");
        }
        room.getWeapon().setMunitionsAmount(room.getWeapon().getMunitionsAmount()-1);
        enemy.setCurrentHealth(1);//remember, ship has an override for this, it's not going to be set to 1
        System.out.println("\n\n**************************E*N*E*M*Y*********************************\n");
        visual(enemy);
        System.out.println("********************************************************************\n\n");
    }
    
    public void enemyCombat(Ship enemy, Ship us)
    {   int chosen;
        float dodge = 0;
        Room attacking;
        Room defending;
        Room repair;
        do{ chosen = (int)(Math.random()* enemy.getRooms().size());
            attacking = enemy.getRoom(chosen);
            
        }while(attacking.getClassification()!=2);
        
        if(attacking.getCurrentHealth() <= 0 || attacking.getWeapon().getMunitionsAmount() <= 0)
        {
            System.out.println("The Enemy's weapon is offline!");
        }
        else
        {
            do{
                chosen = (int)(Math.random()* us.getRooms().size());
                defending = us.getRoom(chosen);
            }while(defending.getCurrentHealth() <= 0);
            for(int i = 0; i< us.getRooms().size();i++){
                if(us.getRoom(i).getClassification() == 3){
                    if(us.getRoom(i).getCurrentHealth() > 0){
                        dodge += .1;
                    }
                    //System.out.println(dodge);
                }
            }
            float damage = attacking.attack(attacking,defending , dodge);

            if (damage != -1)
            {
                System.out.println("Enemy ship has hit "+defending.getName()+ " for " + damage + " damage!");
            }
            else
            {
                System.out.println("Enemy has missed!!!");
            }
            us.setCurrentHealth(1);//remember, ship has an override for this, it's not going to be set to 1
            attacking.getWeapon().setMunitionsAmount(attacking.getWeapon().getMunitionsAmount()-1);
        }
        if(enemy.getEnergy()>0){
            do{ chosen = (int)(Math.random()* enemy.getRooms().size());
                repair = enemy.getRoom(chosen);

            }while(repair.getCurrentHealth() > (repair.getMaxHealth()*(float).8 ));
            float current = (repair.getMaxHealth() - repair.getCurrentHealth()) / 2;
            repair.setCurrentHealth(repair.getCurrentHealth() + current);
            enemy.setEnergy(enemy.getEnergy() - 10);
        }
    }
    
    public void visual(Ship ship){
        ShipBuilder dock = new ShipBuilder();
        System.out.print(dock.setShip(ship));
    }
    
    public int Notification(int num)
    {
        
        switch(num)
        {
            case 1:
                System.out.println("Energy is ready!\n");
                break;
            case 2:
                System.out.println("\n**   *\t**  *\t*\n****\t*****\t**  * *****\n"
                        + "***ENEMY APPROACHES!!!***\n"
                        + "**   *\t**  *\t*\n****\t*****\t**  * *****\n");
                break;
            case 3:
                System.out.println("Destroyed\n");
                break;
            case 4:
                System.out.println("Rebuilt\n");
                break;
                
        //energy ready
        //red alert
        //Weapons armed
        //Engines active
        //life support failing
        //room deactivated or activated
        //room destroyed
        //Your DEAD!!!!!
        }
        return num;
    }
    
    public boolean getEndGame ()
    {
        return dontRun;
    }
}
