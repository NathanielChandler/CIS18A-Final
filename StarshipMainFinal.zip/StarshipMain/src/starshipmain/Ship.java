/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package starshipmain;

import java.util.*;
import java.util.Random;

/**
 *
 * @author Owner
 */
public class Ship extends Stats{
    //Nathaniel Chandler, started 11/12/16
    
    //variables necessary for all ships:
    
    private ArrayList<Room> rooms; //The list of rooms
    private ArrayList<Crew> crewMembers;
    private boolean destroyed;
    
    
    public Ship(String shipName){
        
        super.setName(shipName); //where ship is named initially
        rooms = new ArrayList();
        crewMembers= new ArrayList();
        // these next lines create the default rooms of engine, command, and weapon room
        Room room1 = new Room(1);
        Room room2 = new Room(2);                //< Needs 3 basic rooms to work
        Room room3 = new Room(3);
        // then it adds them automatically to the ship
        rooms.add(room1);
        rooms.add(room2);
        rooms.add(room3);
        this.destroyed = false;
    }
    

    public void addCrew(Crew c){
        //adds a crewmember to the ship
        int a = crewMembers.size();
        rooms.get(a).setOccupant(c);
        rooms.get(a).setIsOccupied(true);
        this.crewMembers.add(c);
    }
    
    public void removeCrew(Crew c){
        //searches for the crewmember, and removes them from arraylist
        for (Crew crew : crewMembers) {
            if(c.equals(crew)){
                crewMembers.remove(crew);
                break;
            }
        }
        
    }
    
    public ArrayList getCrew(){
        return this.crewMembers;
    }
    
    public Crew getCrew(int i){
        return this.crewMembers.get(i);
    }
    
    
    //add room
    public void addRoom(Room r){     // < needs room Class to work
        this.rooms.add(r);
    }
    
    //removes room
    public void removeRoom(int index){
        this.rooms.remove(index);
    }
    
    //get rooms
    public ArrayList getRooms(){
        return this.rooms;
    }
    //get a single room
    public Room getRoom(int i){
        return this.rooms.get(i);
    }
    
    
    //set Max hitpoints (sum of room.HP's)
    @Override
    public void setMaxHealth(float mMaxHealth) {
        float current = 0;
        for (Room room : rooms) {
            //< - - Need room.HP method to work
            current += room.getMaxHealth();
        }
        
        super.setMaxHealth(current);
    }
    
    @Override
    public void setCurrentHealth(float mCurrentHealth) {
        float current = 0;
        for (Room room : rooms) {            //< - - Need room.HP method to work
            current += room.getCurrentHealth();
        }
        
        super.setCurrentHealth(current);
    }
    
    //is Destroyed (returns true if dead)
    public boolean isDestroyed() {
        // KYLE: Added extra energy check
        if(super.getCurrentHealth()<= 0 || super.getEnergy() <= 0){
            this.destroyed = true;
        }
        return destroyed;
    }
  
    @Override
    public void setClassification(int mClassification)
    {
        super.setClassification(0);
    }
    
    @Override
    public void setSpeed(float mSpeed) 
    {
        super.setSpeed(0);
    }
    
    @Override
    public void randomize(float min, float max)
    {
        //Adds either 1, 2, or possibly 3 extra rooms to the base rooms
        int added = (int)(Math.random()*3);
        for(int i = 1; i <= added;i++)
        {
            //Each room added is either a weapon or engine room
            int randomRoomType = (int)(Math.round(Math.random()+ 2));
            
            Room randomRoom = new Room(randomRoomType);
            this.addRoom(randomRoom);
            
        }
        for (Room room : rooms) {
            //< - - Need room.HP method to work
            room.randomize(min,max);
        }
        
        this.setMaxHealth(0);
        this.setCurrentHealth(0);
        this.setClassification(0); 
    }
    
    
}
