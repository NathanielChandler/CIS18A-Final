package starshipmain;







/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author ncc
 */
public class Room extends Stats
{
    private String type;
    private Weapon weapon;
    private boolean hasGun;
    private boolean isOccupied;
    private Crew occupant;    
    
   public Room (int t)
   {           
       super.setClassification(t);
       this.isOccupied = false;
       
       switch(t)
       {
           
           case 1: 
               type = "Command";
               break;
           case 2:
               type = "Weapon";
               hasGun = true;
               break;
           case 3:
               type = "Engine";
               break;
               
           default: hasGun = false;
           
       }
       
       super.setName(type);
       
   }   
   
   
   public void createGun(String n, String t, int ma, int range, int damage){
       
       if(hasGun){
            setWeapon(new Weapon());
            getWeapon().setWeaponsName(n);
           // getWeapon().setWeaponsType(t);
            getWeapon().setMunitionsAmount(ma);
            //getWeapon().setRange(range);
            getWeapon().setDamage(damage);
       }
   }    
       
    /**
     *
     * @param mSpeed
     */
    @Override
    public void setSpeed(float mSpeed) 
    {
        super.setSpeed(0);
    }
    
    @Override
    public void randomize(float min, float max)
    {   
        int c = this.getClassification();
        // if room has a gun, it creates a new gun
        if(hasGun){
            /*int w1 = (int)(Math.random() * 100);
            int w2 = (int)(Math.random() * 100);
            int w3 = (int)(Math.random() * 100);
            // once randomWeaponNameGenerator is done, we'll throw it in here
            this.createGun("default", "default", w1, w2, w3);
            */
            this.weapon = new Weapon();
            weapon.randomWeapon();
            
            
        }
        super.randomize(min, max);
        super.setClassification(c);
        //Below is only for testing purposes
        //System.out.println(this.getClassification() + " " + this.getName());
        //System.out.println(this.getCurrentHealth() + " / " + this.getMaxHealth());
        
    }
       //processes the attacks from one room to another
    public float attack(Room attackers,Room defenders, float dodge){
        //System.out.println("im here now");
        float result;
        //rolls for hit
        float random = (float)(Math.random());
        //if hit is greater than dodge, then defender takes damage 
        //equal to the attacker's weapon damage
        if(random>dodge){
            float r = defenders.getCurrentHealth();
            result = attackers.getWeapon().getDamage();
            if(r>result){
                defenders.setCurrentHealth((r - result));
               // System.out.println("im here now");
            }
            else
            {
                defenders.setCurrentHealth(0);
                //System.out.println("im here now");
            }
            //attack damage will be returned
        }
        //if miss, then -1 is returned
        else{
            result = -1;
           // System.out.println("im here now");
        }
        return result;
    }
    
    /*@Override
    public void setEnergy( int energy)
    {
        super.setEnergy(energy) = energy;
    }*/

    /**
     * @return the weapon
     */
    public Weapon getWeapon() {
        return weapon;
    }

    /**
     * @param weapon the weapon to set
     */
    public void setWeapon(Weapon weapon) {
        this.weapon = weapon;
    }

    /**
     * @return the isOccupied
     */
    public boolean isIsOccupied() {
        return isOccupied;
    }

    /**
     * @param isOccupied the isOccupied to set
     */
    public void setIsOccupied(boolean isOccupied) {
        this.isOccupied = isOccupied;
        if (!this.isOccupied)
        {
            this.setOccupant(null);
        }
    }

    /**
     * @return the occupant
     */
    public Crew getOccupant() {
        return occupant;
    }

    /**
     * @param occupant the occupant to set
     */
    public void setOccupant(Crew occupant) {
        this.occupant = occupant;
    }
}
   
   
   

