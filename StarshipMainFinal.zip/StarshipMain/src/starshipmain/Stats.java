// CREATED BY: Kyle Bue

package starshipmain;

// Abstract class used to create and inject all general stats into created objects
public abstract class Stats 
{
    // What the current health of a room, ship, or character is
    private float currentHealth = 0.0f;
    // What the max health of a room, ship, or character is
    // Made two variables for health since it will change throughout the game
    private float maxHealth = 0.0f;
    // What the classification of a room or character is
    // Made it an INT so it's easier to use rather than messing with strings
    private int classification = 0;
    // How fast a character can move through a ship
    private float speed = 0.0f;
    private int energy = 0;
    private int actionPoints = 0;
    // The name of a room, ship, or character
    private String name = "THIS NAME SHOULD NEVER EXIST DUMMY!!!";

    // GETTERS AND SETTERS
    // ===================================
    public float getCurrentHealth()
    {
        return currentHealth;
    }
    public void setCurrentHealth(float mCurrentHealth) 
    {
        currentHealth = mCurrentHealth;
    }

    public float getMaxHealth() 
    {
        return maxHealth;
    }
    public void setMaxHealth(float mMaxHealth)
    {
        maxHealth = mMaxHealth;
    }

    public int getClassification()
    {
        return classification;
    }
    public void setClassification(int mClassification)
    {
        classification = mClassification;
    }

    public float getSpeed() 
    {
        return speed;
    }
    public void setSpeed(float mSpeed) 
    {
        speed = mSpeed;
    }

    public String getName() 
    {
        return name;
    }
    public void setName(String mName) 
    {
        name = mName;
    }

    public int getEnergy() 
    {
        return energy;
    }
    public void setEnergy(int mEnergy) 
    {
        energy = mEnergy;
    }

    public int getActionPoints()
    {
        return actionPoints;
    }
    public void setActionPoints(int mActionPoints)
    {
        actionPoints = mActionPoints;
    }
    
    //Added by Nathaniel Chandler
    public void randomize(float min, float max){
        //this method randomizes the amount of health(min-max) and the classification(1-3)
        float v1 = (float)((Math.random() * (max-min) )+ min);
        int v2 = (int)((Math.random() * (2) )+ 1);
        
        
        this.setMaxHealth(v1);
        this.setCurrentHealth(v1);
        this.setClassification(v2);
       //tbh, we should probably remove speed from stats and put that exclusively in character
    }
}
