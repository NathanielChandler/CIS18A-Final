/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package starshipmain;



/**
 *
 * @author griffymp
 */
public class Weapon {
    
    private String mWeaponsName;
    //private String mWeaponsType;
    private int mMunitionsAmount;
   // private int mRange;
    private int mDamage;
    
    //Getters and setters set and get variables that will set the variable for everything that belongs to a weapon
    
    public void setWeaponsName(String weaponsName) 
    {
        mWeaponsName = weaponsName;
    }
    public String getWeaponsName()
    {
        return mWeaponsName;
    }
   /* public void setWeaponsType(String weaponsType) 
    {
        mWeaponsType = weaponsType;
    }
    public String getWeaponsType()
    {
        return mWeaponsType;
    }
    */
    public void setMunitionsAmount(int munitionsAmount) 
    {
        mMunitionsAmount = munitionsAmount;
    }
    public int getMunitionsAmount()
    {
        return mMunitionsAmount;
    }
    /*public void setRange(int range) 
    {
        mRange = range;
    }
    public int getRange()
    {
        return range;
    }*/
    public void setDamage(int damage) 
    {
        mDamage = damage;
    }
    public int getDamage()
    {
        return mDamage;
    }
    
    public void randomWeapon(){
        RandomWeaponsGenerator bob = new RandomWeaponsGenerator();
        Weapon n;
        n = bob.rnd();
        this.setWeaponsName(n.getWeaponsName());
        this.setMunitionsAmount(n.getMunitionsAmount());
        this.setDamage(n.getDamage());
        
    }
    
    
}
